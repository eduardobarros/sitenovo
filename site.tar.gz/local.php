<!DOCTYPE html>
<html lang="pt-br">
<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <title>Sobre o evento - Congresso Dasa Oncologia 2023</title>
  <meta name="description" content="Um evento totalmente voltado para o compartilhamento do conhecimento científico, pensado e organizado detalhadamente para levar aos nossos convidados o que há de mais inovador e moderno sobre os cuidados oncológicos, visando uma medicina preditiva, preventiva e cuidar sempre e por inteiro." />
  <meta name="robots" content="noindex">

  <meta property="og:title" content="Congresso Dasa Oncologia 2023" />
  <meta property="og:site_name" content="Dasa" />
  <meta property="og:description" content="Um evento totalmente voltado para o compartilhamento do conhecimento científico, pensado e organizado detalhadamente para levar aos nossos convidados o que há de mais inovador e moderno sobre os cuidados oncológicos, visando uma medicina preditiva, preventiva e cuidar sempre e por inteiro.">

  <meta property="og:type" content="website">
  <meta property="og:locale" content="pt-br" />

  <meta property="og:image" content="https://placcopazzinidev09.com.br/assets/img/og.jpg">
  <meta property="og:image:type" content="image/jpg">
  <meta property="og:image:width" content="1200">
  <meta property="og:image:height" content="630">

  <meta property="twitter:title" content="Congresso Dasa Oncologia 2023" />
  <meta property="twitter:description" content="O Programa de Compliance da Dasa é uma ferramenta de todos a quem ele se aplica e consolida o conjunto de medidas institucionais para o desenvolvimento de suas atividades de forma ética e íntegra." />
  <meta property="twitter:image" content="https://placcopazzinidev09.com.br/assets/img/og.jpg" />

  <link rel="icon" type="image/png" href="assets/img/favicon.png">
  <link rel="shortcut icon" href="assets/img/favicon.png" />

  <!-- PRELOAD -->
  <link rel="preload" as="style" href="assets/css/main.css" >
  <link rel="preload" as="style" href="assets/css/flickity-docs.css" >
  <link rel="preload" as="script" href="assets/js/jquery.min.js">
  <link rel="preload" as="script" href="assets/js/scroll-out.js">
  <link rel="preload" as="script" href="assets/js/scripts.js">

  <link rel="preload" as="image" src="assets/img/slide01.webp" >
  <link rel="preload" as="image" src="assets/img/slide02.webp" >
  <link rel="preload" as="image" src="assets/img/slide03.webp" >
  <link rel="preload" as="image" src="assets/img/slide04.webp" >
  <link rel="preload" as="image" src="assets/img/slide05.webp" >

  <link rel="stylesheet" href="assets/css/main.css">
  <link rel="stylesheet" href="assets/css/flickity-docs.css">

</head>
<body>

  <?php include 'inc/header.php' ?>
  <content>

    <div class="breadcrumb">Local do evento</div>

    <div class="conteudo">
      <h1>Hotel JW Marriott</h1>
        <div class="conteudo-textos" style="text-align: center;">
        <p>O evento será realizado no Hotel JW Marriott, que possui um conceito inspirado na beleza natural do mundo.</p>
        <p>O espaço é todo revestido de pedras brasileiras, que trazem imponência, requinte e sofisticação ao espaço, além de oferecer cuidado e conforto, marcas presentes também em Dasa Oncologia.</p>

        <div class="slide-hotel" data-flickity='{ "groupCells": true, "loop": true, "autoPlay": 4000, "draggable": true, "pauseAutoPlayOnHover": false, "pauseAutoPlayOnClick": false, "adaptiveHeight": true }'>

          <img src="assets/img/hotel.webp" alt="Hotel JW Marriott">
          <img src="assets/img/hotel2.webp" alt="Hotel JW Marriott">
          <img src="assets/img/hotel3.webp" alt="Hotel JW Marriott">
          <img src="assets/img/hotel4.webp" alt="Hotel JW Marriott">
          <img src="assets/img/hotel5.webp" alt="Hotel JW Marriott">
          <img src="assets/img/hotel6.webp" alt="Hotel JW Marriott">
          <img src="assets/img/hotel7.webp" alt="Hotel JW Marriott">
          <img src="assets/img/hotel8.webp" alt="Hotel JW Marriott">
        </div>


        <p style="font-size: 24px; line-height: 1;"><span style="font-family: DasaBold, sans-serif;">Endereço:</span> Torre Hotel - Av. das Nações Unidas, Chácara Santo Antônio, São Paulo - SP, 04794-000</p>
        <iframe class="conteudo-mapa" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d14622.621826835657!2d-46.7121489468613!3d-23.616686510186376!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x94ce50ccd397a87f%3A0x7cad5295e0b55177!2zVG9ycmUgTmHDp8O1ZXMgVW5pZGFz!5e0!3m2!1spt-BR!2sbr!4v1694785228623!5m2!1spt-BR!2sbr" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>

      </div>
    </div>

  </content>
    <?php include 'inc/footer.php' ?>
  <script src="assets/js/jquery.min.js"></script>
  <script src="assets/js/scroll-out.js"></script>
  <script src="assets/js/scripts.js"></script>
  <script src="assets/js/flickity-docs.min.js"></script>
</body>
</html>