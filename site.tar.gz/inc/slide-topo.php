    <section class="slide-topo">
      <img src="assets/img/slide-topo-mobile.webp" loading="lazy" class="slide-topo-img-mobile" alt="Dasa Compliance">
      <img src="assets/img/slide-topo-desktop.webp" loading="lazy" class="slide-topo-img-desktop" alt="Dasa Compliance">
      <div class="slide-topo-textos">
        <h1>Compliance na Dasa</h1>
        <p>O comprometimento com a ética e integridade é exigido de todos os colaboradores, administradores, terceiros e clientes que se relacionam com a Dasa e deve estar presente no nosso dia a dia, na condução dos negócios e em cada tomada de decisão alinhado ao nosso propósito de ser a saúde que as pessoas desejam e que o mundo precisa.</p>
        <a href="#palavra-dos-presidentes" title="Saiba mais"><img src="assets/img/seta-branca.svg" alt="Saiva mais"></a>
      </div>
    </section>