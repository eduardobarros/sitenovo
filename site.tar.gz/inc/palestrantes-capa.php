    <section class="palestrantes-capa">
      <h2>Palestrantes</h2>


      <div class="palestrantes-capa-slide" id="palestrantes-capa-slide" data-flickity='{ "groupCells": true, "loop": true, "autoPlay": 4000, "draggable": true, "pauseAutoPlayOnHover": false, "pauseAutoPlayOnClick": false, "adaptiveHeight": true }'>

        <div class="palestrantes-capa-item" title="Adriana Alves">
          <img src="assets/img/personas/dra-adriana-alves.webp" alt="Adriana Alves">
          <h5>Adriana Alves <span>Diretoria Assistencial de Oncologia Dasa</span></h5>
        </div>
        
        <div class="palestrantes-capa-item" title="Dra. Aknar Calabrich">
          <img src="assets/img/personas/dra-aknar-calabrich.webp" alt="Dra. Aknar Calabrich">
          <h5>Dra. Aknar Calabrich <span>Oncologista Clínica<br> CRM 21855/BA</span></h5>
        </div>
        
        <div class="palestrantes-capa-item" title="Dra. Anelisa Coutinho">
          <img src="assets/img/personas/dra-anelisa-coutinho.webp" alt="Dra. Anelisa Coutinho">
          <h5>Dra. Anelisa Coutinho <span>Oncologista Clínica<br> CRM 11452/BA</span></h5>
        </div>
        
        <div class="palestrantes-capa-item" title="Dr. Augusto Mota">
          <img src="assets/img/personas/dr-augusto-mota.webp" alt="Dr. Augusto Mota">
          <h5>Dr. Augusto Mota <span>Oncologista Clínico<br> CRM 14397 /BA</span></h5>
        </div>
        
        <div class="palestrantes-capa-item" title="Dra. Carolina Kawamura">
          <img src="assets/img/personas/dra-carolina-kawamura.webp" alt="Dra. Carolina Kawamura">
          <h5>Dra. Carolina Kawamura <span>Oncologista Clínico <br>CRM 119713/SP</span></h5>
        </div>
        
        <div class="palestrantes-capa-item" title="Dra. Caroline Chaul">
          <img src="assets/img/personas/dra-caroline-chaul.webp" alt="Dra. Caroline Chaul">
          <h5>Dra. Caroline Chaul <span>Oncologista Clínica<br> CRM 131520/SP</span></h5>
        </div>
        
        <div class="palestrantes-capa-item" title="Dr. Celso Arrais">
          <img src="assets/img/personas/dr-celso-arrais.webp" alt="Dr. Celso Arrais">
          <h5>Dr. Celso Arrais <span>Onco-hematologia<br> CRM 98682/SP</span></h5>
        </div>
        
        <div class="palestrantes-capa-item" title="Dr. Fernando Vidigal">
          <img src="assets/img/personas/dr-fernando-vidigal.webp" alt="Dr. Fernando Vidigal">
          <h5>Dr. Fernando Vidigal <span>Oncologista Clínico<br> CRM 22020/DF</span></h5>
        </div>
        
        <div class="palestrantes-capa-item" title="Dr. Gustavo Fernandes">
          <img src="assets/img/personas/dr-gustavo-fernandes-co-chair.webp" alt="Dr. Gustavo Fernandes">
          <h5>Dr. Gustavo Fernandes <span>Oncologista Clínico e Hematologista<br> CRM 16558/DF</span></h5>
        </div>
        
        <div class="palestrantes-capa-item" title="Dr. Iuri Melo">
          <img src="assets/img/personas/dr-iuri-santana.webp" alt="Dr. Iuri Melo">
          <h5>Dr. Iuri Melo <span>Oncologista Clínico<br> CRM 26191/BA</span></h5>
        </div>
        
        <div class="palestrantes-capa-item" title="Dr. Luiz Henrique de Lima Araújo">
          <img src="assets/img/personas/dr-luiz-henrique-de-lima-araujo-chair.webp" alt="Dr. Luiz Henrique de Lima Araújo">
          <h5>Dr. Luiz Henrique de Lima Araújo <span>Oncologista Clínico<br> CRM 797324/RJ</span></h5>
        </div>
        
        <div class="palestrantes-capa-item" title="Dr. Marcos Tavares">
          <img src="assets/img/personas/dr-marcos-tavares.webp" alt="Dr. Marcos Tavares">
          <h5>Dr. Marcos Tavares <span>Pneumologista <br>CRM 121046/SP</span></h5>
        </div>
        
        <div class="palestrantes-capa-item" title="Dra. Mariana Scaranti">
          <img src="assets/img/personas/dra-mariana-scaranti.webp" alt="Dra. Mariana Scaranti">
          <h5>Dra. Mariana Scaranti <span>Oncologista Clínica<br> CRM 144409/SP</span></h5>
        </div>
        
        <div class="palestrantes-capa-item" title="Dr. Romulo Barroso">
          <img src="assets/img/personas/dr-romulo-barroso.webp" alt="Dr. Romulo Barroso">
          <h5>Dr. Romulo Barroso <span>Oncologista Clínico<br> CRM 25325/DF</span></h5>
        </div>
        
        <div class="palestrantes-capa-item" title="Dr. Tiago Kenji">
          <img src="assets/img/personas/dr-tiago-kenji.webp" alt="Dr. Tiago Kenji">
          <h5>Dr. Tiago Kenji <span>Oncologista Clínico<br> CRM 125042/SP</span></h5>
        </div>
        
        <div class="palestrantes-capa-item" title="Dra. Thamine Lessa">
          <img src="assets/img/personas/dra-thamine-lessa.webp" alt="Dra. Thamine Lessa">
          <h5>Dra. Thamine Lessa <span>Pneumologista<br> CRM 12958/BA</span></h5>
        </div>

      </div>

      <a href="palestrantes.php" class="botao palestrantes-capa-botao" title="Todos os palestrantes">Todos os palestrantes</a>

    </section>