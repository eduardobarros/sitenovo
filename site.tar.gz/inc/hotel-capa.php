    <section class="hotel-capa">
      <img src="assets/img/hotel.webp" alt="Local do evento - Hotel JW Marriott" class="hotel-capa-img">
      <div class="hotel-capa-textos">
        <h2><span>Local do evento</span> Hotel JW Marriott</h2>
        <p class="hotel-capa-endereco">Torre Hotel - Av. das Nações Unidas, <br>Chácara Santo Antônio, São Paulo - SP, 04794-000</p>
        <div class="hotel-capa-texto">
          <p>O evento será realizado no Hotel JW Marriott, que possui um conceito inspirado na beleza natural do mundo. </p>
          <p>O espaço é todo revestido de pedras brasileiras, que trazem imponência, requinte e sofisticação ao espaço, além de oferecer cuidado e conforto, marcas presentes também em Dasa Oncologia. </p>
        </div>
        <a href="https://maps.app.goo.gl/B94soWvzsr6JKYgS8" target="_blank" title="Torre Hotel - Av. das Nações Unidas"><img src="assets/img/mapa.webp" alt="Hotel JW Marriott - Como chegar" class="hotel-capa-mapa"></a>
        <a href="/local" class="botao hotel-capa-botao" title="Saiba mais">Saiba mais</a>
      </div>
    </section>