<!DOCTYPE html>
<html lang="pt-br">
<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <title>Programação - Congresso Dasa Oncologia 2023</title>
  <meta name="description" content="Um evento totalmente voltado para o compartilhamento do conhecimento científico, pensado e organizado detalhadamente para levar aos nossos convidados o que há de mais inovador e moderno sobre os cuidados oncológicos, visando uma medicina preditiva, preventiva e cuidar sempre e por inteiro." />
  <meta name="robots" content="noindex">

  <meta property="og:title" content="Congresso Dasa Oncologia 2023" />
  <meta property="og:site_name" content="Dasa" />
  <meta property="og:description" content="Um evento totalmente voltado para o compartilhamento do conhecimento científico, pensado e organizado detalhadamente para levar aos nossos convidados o que há de mais inovador e moderno sobre os cuidados oncológicos, visando uma medicina preditiva, preventiva e cuidar sempre e por inteiro.">

  <meta property="og:type" content="website">
  <meta property="og:locale" content="pt-br" />

  <meta property="og:image" content="https://placcopazzinidev09.com.br/assets/img/og.jpg">
  <meta property="og:image:type" content="image/jpg">
  <meta property="og:image:width" content="1200">
  <meta property="og:image:height" content="630">

  <meta property="twitter:title" content="Congresso Dasa Oncologia 2023" />
  <meta property="twitter:description" content="O Programa de Compliance da Dasa é uma ferramenta de todos a quem ele se aplica e consolida o conjunto de medidas institucionais para o desenvolvimento de suas atividades de forma ética e íntegra." />
  <meta property="twitter:image" content="https://placcopazzinidev09.com.br/assets/img/og.jpg" />

  <link rel="icon" type="image/png" href="assets/img/favicon.png">
  <link rel="shortcut icon" href="assets/img/favicon.png" />

  <!-- PRELOAD -->
  <link rel="preload" as="style" href="assets/css/main.css" >
  <link rel="preload" as="script" href="assets/js/jquery.min.js">
  <link rel="preload" as="script" href="assets/js/scroll-out.js">
  <link rel="preload" as="script" href="assets/js/scripts.js">

  <link rel="preload" as="image" src="assets/img/slide01.webp" >
  <link rel="preload" as="image" src="assets/img/slide02.webp" >
  <link rel="preload" as="image" src="assets/img/slide03.webp" >
  <link rel="preload" as="image" src="assets/img/slide04.webp" >
  <link rel="preload" as="image" src="assets/img/slide05.webp" >

  <link rel="stylesheet" href="assets/css/main.css">
  <link rel="stylesheet" href="assets/css/flickity-docs.css">

</head>
<body>

  <?php include 'inc/header.php' ?>
  <content>

    <div class="breadcrumb">Programação do evento</div>

    <div class="conteudo conteudo-programacao">
      <h1>Programação do Congresso Dasa Oncologia</h1>
        <div class="conteudo-textos">

        <!-- TABS -->



        <div class="nav_tabs">
          <ul>

            <li>
              <input type="radio" name="tabs" checked class="rd_tabs" id="tab1">
              <label for="tab1"><span class="programacao-data">23 NOVEMBRO</span></label>
              <content class="programacao-conteudo">

                <div class="programacao-abertura">
                  <div class="programacao-abertura-data">23 de novembro</div>
                  <div class="programacao-abertura-titulo"><span>Aula Magna</span> Gustavo Fernandes </div>
                  <div class="programacao-abertura-texto">Solenidade de abertura do Congresso</div>
                </div>

              </content>
            </li>

            <li>
              <input type="radio" name="tabs" class="rd_tabs" id="tab3">
              <label for="tab3"><span class="programacao-data">24 NOVEMBRO</span></label>
              <content class="programacao-conteudo">

                
                <!-- BLOCO Quinta-feira, 24 de novembro - Sala 01 -->
                <div class="programacao-bloco">

                  <h2>24 de novembro <span>Sala 01</span></h2>

                  <h3 class="programacao-conteudo-h3-titulo">8h às 12h30 – MAMA</h3>
                  <h4><span>8h00 às 8h15</span><br> Desafios na avaliação radiológica do carcinoma lobular invasivo</h4>
                  <p>Palestrante: Almir Bittencourt - SP</p>
                  <h4><span>8h15 às 8h30</span><br> Uso do PET-FES - Indicações e limitações</h4>
                  <p>Palestrante: Renata dos Anjos – SP</p>
                  <h4><span>8h30 às 8h45</span><br> Abordagem axilar após terapia neoadjuvante</h4>
                  <p>Palestrante: Juliana Orrico – BA</p>
                  <h4><span>8h45 às 9h00</span><br> Fertilidade e câncer de mama: o que há de novo?</h4>
                  <p>Palestrante: Renata Arakelian - SP</p>
                  <h4><span>9h00 às 9h30</span><br> Discussão</h4>
                  <p></p>
                  <h4><span>9h30 às 10h00</span> – Medicina de precisão no câncer de mama RH+ avançado: presente e futuro</h4>
                  <p>Palestrante: Internacional</p>

                  <h3 class="programacao-conteudo-h3-intervalo">10h00 às 10h30- Intervalo</h3>

                  <h4><span>10h30 às 10h45</span><br> Tratamento da doença TN inicial</h4>
                  <p>Palestrante: Luiza Weis - DF</p>
                  <h4><span>10h45 às 11h00</span><br> Tratamento da doença TN avançada</h4>
                  <p>Palestrante: Mayana Lopes - BA</p>
                  <h4><span>11h00 às 11h15</span><br> Adjuvância hormonal em 2023: quando os inibidores de CDK4/6 estão indicados?</h4>
                  <p>Palestrante: Bruna Zucchetti - SP</p>
                  <h4><span>11h15 às 11h30</span><br> Tratamento da doença RH+ avançada após falha dos inibidores de CDK4/6</h4>
                  <p>Palestrante: Romualdo Barroso</p>
                  <h4><span>11h30 às 12h00</span><br> Discussão</h4>
                  <p></p>
                  <h4><span>12h00 às 12h30</span><br> Inteligência artificial no diagnóstico, prognóstico definição de condutas no câncer de mama</h4>
                  <p>Palestrante:</p>


                  <h3 class="programacao-conteudo-h3-intervalo">12h30 às 14h00 - Simpósio Satélite: Patrocinado</h3>

                  <h4><span>14h às 16h</span><br> Saúde da mulher em oncologia</h4>
                  <p>Palestrante:</p>                  <h4><span>14h00 às 14h15</span><br> Preservação de Fertilidade em Oncologia</h4>
                  <p>Palestrante:</p>
                  <h4><span>14h15 às 14h30</span><br> Impacto do tratamento oncológico em sexualidade</h4>
                  <p>Palestrante:</p>
                  <h4><span>14h30 ás 14h45</span><br> Rastreamento Oncológico na Mulher Trans</h4>
                  <p>Palestrante:</p>
                  <h4><span>14h45 às 15h00</span><br> Discussão </h4>
                  <p>Palestrante:</p>
                  <h4><span>15h00 às 15h15</span><br> Reposição hormonal: aumenta o risco de câncer?</h4>
                  <p>Palestrante:</p>
                  <h4><span>15h15 às 15h30</span><br> Vacinação contra HPV: o dia depois da incorporação da nonavalente?</h4>
                  <p>Palestrante:</p>
                  <h4><span>15h30 às 15h45</span><br> Saúde da Mulher e o Metaverso</h4>
                  <p>Palestrante:</p>
                  <h4><span>15:45 às 16h00</span><br> Discussão </h4>
                  <p>Palestrante:</p>

                  <h3 class="programacao-conteudo-h3-titulo">16h30 às 18h30 - Oncoginecologia</h3>

                  <h4><span>16h30 às 16h45</span><br> A Dasa e validação do HRD One</h4>
                  <p>Palestrante: Cristovam Scapulatempo (SP)</p>
                  <h4><span>16h45 às 17h00</span><br> Terapia de manutenção em primeira linha para HRD+ BRCAwt</h4>
                  <p>Palestrante: Mariana Scaranti (SP)</p>
                  <h4><span>17h00 às 17h15</span><br> Citorredução secundária em câncer de ovário: para quem?</h4>
                  <p>Palestrante: André Perina (SP)</p>
                  <h4><span>17h15 às 17h30</span> <br>Discussão</h4>
                  <p></p>
                  <h4><span>17h30 às 17h45</span><br> A classificação molecular do câncer de endométrio: modelo Dasa</h4>
                  <p>Palestrante: Gustavo Focchi (SP)</p>
                  <h4><span>17h45 às 18h00</span><br> Imunoterapia em câncer de endométrio</h4>
                  <p>Palestrante: Marcella Salvadori (BA)</p>
                  <h4><span>18h00 às 18h15</span><br> Determinação de campo de radioterapia: Extensão de campo profilático X estadiamento invasivo</h4>
                  <p>Palestrante: Lorine Radioterapia (SP)</p>
                  <h4><span>18h15 às 18h30</span> <br>Discussão</h4>

                  <h3 class="programacao-conteudo-h3-intervalo">18h30 – Encerramento</h3>

                </div>
                <!-- BLOCO Quinta-feira, 24 de novembro - Sala 01 -->


                <!-- BLOCO Quinta-feira, 24 de novembro - Sala 02 -->
                <div class="programacao-bloco">

                  <h2>24 de novembro <span>Sala 02</span></h2>

                  <h3 class="programacao-conteudo-h3-titulo">8h00 à 10h00 – Pulmão</h3>
                  <h4><span>8h00 às 8h05</span> <br>Caso 1 (estadio II)</h4>
                  <p>Palestrante: Manuel Cruz (SP)</p>
                  <h4><span>8h05 às 8h15</span> <br>Desafios para implementação de programa de rastreamento de câncer de pulmão</h4>
                  <p>Palestrante: </p>
                  <h4><span>8h15 às 8h25</span> <br>Selecionando o melhor paciente para cirurgia sublobar</h4>
                  <p>Palestrante: Gustavo Gattás (RJ)</p>
                  <h4><span>8h25 às 8h35</span> <br>SBRT na doença inicial</h4>
                  <p>Palestrante: Paula Pratti (SP)</p>
                  <h4><span>8h35 às 9h00</span> <br>Discussão</h4>
                  <p></p>
                  <h4><span>9h00 às 9h05</span> <br>Caso 2 (estadio III)</h4>
                  <p>Palestrante: Cecilia Longo (RJ)</p>
                  <h4><span>9h05 às 9h15</span> <br>Tratamento do estadio III</h4>
                  <p>Palestrante: Carolina Kawamura Haddad (SP)</p>
                  <h4><span>9h15 às 9h25</span> <br>Manejo das toxicidades pulmonares no tratamento multimodal</h4>
                  <p>Palestrante: Thamine Lessa (BA)</p>
                  <h4><span>9h25 às 9h35</span> <br>Uso de ctDNA em câncer de pulmão ressecável</h4>
                  <p>Palestrante: Luiz Araújo (RJ)</p>
                  <h4><span>9h35 às 10h00</span> <br>Discussão</h4>

                  <h3 class="programacao-conteudo-h3-intervalo">10h00 às 10h30- Intervalo</h3>

                  <h4><span>10h30 às 10h35</span> <br>Caso 3 (avançado mutado)</h4>
                  <p>Palestrante: Klayton Ribeiro (MA)</p>
                  <h4><span>10h35 às 10h45</span> <br>Papel da cirurgia na doença oligometastática</h4>
                  <p>Palestrante: Iury Melo (BA)</p>
                  <h4><span>10h45 às 10h55</span> <br>ADCs em câncer de pulmão: o que está por vir</h4>
                  <p>Palestrante: Aknar Calabrich (BA)</p>
                  <h4><span>10h55 às 11h05</span> <br>Cuidados paliativos em câncer de pulmão</h4>
                  <p>Palestrante: João Thomé (SP)</p>
                  <h4><span>11h05 às 11h30</span> <br>Discussão</h4>
                  <p></p>
                  <h4><span>11h30 às 11h35</span> <br>Caso 4 (neoadjuvancia)</h4>
                  <p>Palestrante: Marcos Nunes (SP)</p>
                  <h4><span>11h35 às 11h45</span> <br>Reabilitação cardiopulmonar</h4>
                  <p>Palestrante: Suzana Pimenta (SP)</p>
                  <h4><span>11h55 às 12h05</span> <br>Avaliação molecular na doença não metastática</h4>
                  <p>Palestrante: Felipe D'Almeida Costa (SP)</p>
                  <h4><span>12h05 às 12h30</span> <br>Desafios cirúrgicos após imunoterapia neoadjuvante</h4>
                  <p>Palestrante: Augusto Ishy (SP)</p>

                  <h4 class="programacao-conteudo-h3-intervalo">12h30 às 13h10 - Simpósio Satélite: Patrocinado</h4>
                  <h4 class="programacao-conteudo-h3-intervalo">13h20 às 14h00 - Simpósio Satélite: Patrocinado</h4>

                  <h3 class="programacao-conteudo-h3-titulo">14h00 à 16h00 - Imagem em Oncologia (foco tórax/ meta SNC)</h3>
                  <h4><span>14h00 às 14h05</span> <br>Caso 5 (achado incidental no torax + meta cerebral)</h4>
                  <p>Palestrante: Ludmilla Mineiro (SP)</p>
                  <h4><span>14h05 às 14h20</span> <br>Manejo do achado incidental de nódulo pulmonar</h4>
                  <p>Palestrante: Gustavo Telles (SP)</p>
                  <h4><span>14h20 às 14h35</span> <br>Tratamento de metástases cerebrais na era da terapia alvo e imunoterapia</h4>
                  <p>Palestrante: Karina Sacardo (SP)</p>
                  <h4><span>14h35 às 14h50</span> <br>Manejo de radionecrose</h4>
                  <p>Palestrante: Caroline Chaul (SP)</p>
                  <h4><span>14h50 às 15h00</span> <br>Discussão</h4>
                  <p></p>
                  <h4><span>15h00 às 15h30</span> <br>Inteligência Artificial na radiologia torácica</h4>
                  <p>Palestrante: Felipe Kitamura (SP)</p>
                  <h4><span>15h30 às 16h00</span> <br>Diagnósticos diferenciais de lesões pulmonares</h4>
                  <p>Palestrante: Isabela Muller (BA)</p>

                  <h3 class="programacao-conteudo-h3-titulo">16h00 às 16h30 – Debatedores</h3>
                  <ul style="list-style: initial; display: block; margin: 0 0 30px 30px; border: none;">
                    <li>Suzana Pimenta (SP) </li>
                    <li>Fernando Vidigal (DF)</li>
                    <li>Helena Alves Costa Pereira (SP)</li>
                  </ul>

                  <h3 class="programacao-conteudo-h3-intervalo">16h00 às 16h30 - Intervalo</h3>

                  <h3 class="programacao-conteudo-h3-titulo">16h30 às 18h30 - Neuro</h3>

                  <h4><span>16h30 às 16h50</span> <br>Imagem em lesões em SNC: do diagnostico ao seguimento</h4>
                  <p>Palestrante: Dr. Antonio Rocha ou Renato Hoffman</p>
                  <h4><span>16h50 às 17h10</span> <br>Abordagem cirúrgica de lesões em SNC</h4>
                  <p>Palestrante: Dr. Iuri Neville</p>
                  <h4><span>17h10 às 17h30</span> <br>Testes moleculares em gliomas</h4>
                  <p>Palestrante: Dr. Felipe D'Almeida</p>
                  <h4><span>17h30 às 17h50</span> <br>Inovações na Radioterapia de SNC</h4>
                  <p>Palestrante:</p>
                  <h4><span>17h50 às 18h10</span> <br>Terapia baseada em alteração molecular: evidencia em tumores de SNC</h4>
                  <p>Palestrante:</p>
                  <h4><span>18h10 às 18h30</span> <br>CAR-T Cell e vírus em tumores de SNC: Realidade?</h4>
                  <p>Palestrante:</p>

                  <h3 class="programacao-conteudo-h3-intervalo">18h30 – Encerramento </h3>

                </div>
                <!-- BLOCO Quinta-feira, 24 de novembro - Sala 02 -->


                <!-- BLOCO Quinta-feira, 24 de novembro - Sala 03 -->
                <div class="programacao-bloco">

                  <h2>24 de novembro <span>Sala 03</span></h2>

                  <h3 class="programacao-conteudo-h3-titulo">8h00 à 10h00 - GI Alto</h3>
                  <h4><span>h00 às 8h15</span> <br>Marcadores moleculares em GI</h4>
                  <p>Palestrante: Gustavo Fernandes-DF</p>
                  <h4><span>h15 às 8h30</span> <br>Aplicabilidade do ct-DNA em GI em 2023</h4>
                  <p>Palestrante: </p>
                  <h4><span>h30 às 8h45</span> <br>Microbiota: futuro ou realidade?</h4>
                  <p>Palestrante: Romualdo Barroso-DF</p>
                  <h4><span>h45 às 9h00</span> <br>Discussão </h4>
                  <p></p>
                  <h4><span>h00 às 9h15</span> <br>TNE – aplicações de medicina nuclear no diagnóstico e tratamento</h4>
                  <p>Palestrante: José Leite - RJ</p>
                  <h4><span>h15 às 9h30</span> <br>Radiologia em reto: o que importa</h4>
                  <p>Palestrante: Maira Veloso - DF</p>
                  <h4><span>h30 às 9h45</span> <br>Tratamento dos tumores localmente avançados do reto</h4>
                  <p>Palestrante: Juliana Florinda-RN</p>
                  <h4><span>h45 às 10h00</span> <br>Discussão </h4>

                  <h3 class="programacao-conteudo-h3-intervalo">10h00 às 10h30 - Intervalo </h3>

                  <h3 class="programacao-conteudo-h3-titulo">10h30 às 12h30 - Gi baixo</h3>
                  <h4><span>10h30 às 10h45</span> <br>Imunoterapia em GI : o que temos?</h4>
                  <p>Palestrante: Anelisa Coutinho-SSA</p>
                  <h4><span>10h45 às 11h00</span> <br>O que há de novo em câncer pancreatobiliar?</h4>
                  <p>Palestrante: Felipe Moraes-SP</p>
                  <h4><span>11h00 às 11h15</span> <br>Terapia local: quando e pra quem? eletroporação; ARF; microondas, etc</h4>
                  <p>Palestrante: Mauricio Amoedo-SSA</p>
                  <h4><span>11h15 às 11h30</span> <br>Discussão</h4>
                  <p></p>
                  <h4><span>11h30 às 11h45</span> <br>Há espaço para transplantes na doença metastática?</h4>
                  <p>Palestrante: Eduardo Fernandes - RJ</p>
                  <h4><span>11h45 às 12h00</span> <br>Diagnóstico e manejo da hepatotoxicidade relacionada a terapia antineoplásica</h4>
                  <p>Palestrante: Vivianne Mello- SSA</p>
                  <h4><span>12h00 às 12h15</span> <br>Bons hábitos úteis em oncologia GI: quais dados reais? (Alimentação e atividade física)</h4>
                  <p>Palestrante: Thomás Rivelli - SP</p>
                  <h4><span>12h15 às 12h30</span> <br>Discussão </h4>

                  <h3 class="programacao-conteudo-h3-intervalo">12h30 às 14h00 – Simpósio Satélite </h3>

                  <h3 class="programacao-conteudo-h3-titulo">14h00 às 16h00 - Medicina Intensiva e Cardio-oncologia</h3>
                  <h4><span>14h00 às 14h15</span> <br>O Paciente oncológico na UTI</h4>
                  <p>Palestrante: Marcos Soares Tavares</p>
                  <h4><span>14h15 às 14h30</span> <br>Insuficiência respiratória no paciente oncológico</h4>
                  <p>Palestrante: Antônio Paulo Ramos Filho</p>
                  <h4><span>14h30 às 14h45</span> <br>Disfunção renal no paciente oncológico na UTI</h4>
                  <p>Palestrante: José Mauro Vieira Júnior</p>
                  <h4><span>14h45 às 15h00</span> <br>Discussão</h4>
                  <p>Moderador: Raphael Oliveira</p>
                  <h4><span>15h00 às 15h15</span> <br>Desafio das síndromes coronarianas nos pacientes em tratamento oncológico</h4>
                  <p>Palestrante: Eduardo Gomes Lima</p>
                  <h4><span>15h15 às 15h30</span> <br>Manejo do paciente neutropênico na UTI</h4>
                  <p>Palestrante: Celso Padovesi</p>
                  <h4><span>15h30 às 15h45</span> <br>Testes rápidos para identificação de agentes infecciosos nos pacientes oncológicos em sepse</h4>
                  <p>Palestrante: Edson Abdala</p>
                  <h4><span>15h45 às 16h00</span> <br>Discussão</h4>
                  <p>Moderador: Danilo Noritomi</p>

                  <h3 class="programacao-conteudo-h3-intervalo">16h00 às 16h30 – Intervalo </h3>

                  <h3 class="programacao-conteudo-h3-titulo">16h30 às 18h30 – Experiência do paciente</h3>
                  <h4><span>16h30 às 16h35</span> <br>Abertura e mediadora</h4>
                  <p>Palestrante: Adriana Alves</p>
                  <h4><span>16h35 às 17h35</span> <br>Experiência do Paciente: Papel da Equipe Multiprofissional na Jornada Oncológica</h4>
                  <p>Palestrante:</p>
                  <h4><span>17h35 às 17h55</span> <br>Navegação Oncológica – Modelo de Linhas de Cuidado</h4>
                  <p>Palestrante: </p>
                  <h4><span>17h55 às 18h10</span> <br>Práticas Integrativas</h4>
                  <p>Palestrante: Enf. Paola Mercer</p>
                  <h4><span>18h10 às 18h30</span> <br>Atenção Integral – Cuidados Paliativos</h4>
                  <p>Palestrante: Dr. Vitor Carlos</p>

                  <h3 class="programacao-conteudo-h3-intervalo">18h30 - Encerramento </h3>

                </div>
                <!-- BLOCO Quinta-feira, 24 de novembro - Sala 03 -->




              </content>
            </li>

            <li>
              <input type="radio" name="tabs" class="rd_tabs" id="tab2">
              <label for="tab2"><h2 class="programacao-data">25 NOVEMBRO</h2></label>
              <content class="programacao-conteudo">


                <!-- BLOCO Quinta-feira, 25 de novembro - Sala 01 -->
                <div class="programacao-bloco">

                  <h2>25 de novembro <span>Sala 01</span></h2>

                  <h3 class="programacao-conteudo-h3-titulo">8h00 às 12h30 – Geniturinário</h3>
                  <h4><span>8h00 às 8h15</span> <br>Próstata (Doença não metastática)</h4>
                  <p>Palestrante:</p>
                  <h4><span>8h15 às 8h30</span> <br>Caso clínico de doença de risco muito alto</h4>
                  <p>Palestrante: </p>
                  <h4><span>8h30 às 8h45</span> <br>Caso clínico de recidiva bioquímica de alto risco</h4>
                  <p>Palestrante: </p>
                  <h4><span>8h45 às 9h00</span> <br>Discussão</h4>
                  <p></p>
                  <h4><span>9h00 às 9h15</span> <br>Caso clínico de doença oligometastática</h4>
                  <p>Palestrante: </p>
                  <h4><span>9h15 às 9:30</span> <br>Intensificação do tratamento no câncer de próstata metastático sensível à castração</h4>
                  <p>Palestrante: </p>
                  <h4><span>9h30 às 9h45</span> <br>Tratamento da doença metastática resistente à castração</h4>
                  <p>Palestrante: </p>
                  <h4><span>9h45 às 10h00</span> <br>Discussão</h4>
                  <p></p>

                  <h3 class="programacao-conteudo-h3-intervalo">10h00 às 10h30- Intervalo</h3>
                  <h4><span>10h30 às 10h45</span> <br>Caso clínico de doença não-músculo invasiva de alto risco</h4>
                  <p>Palestrante: </p>
                  <h4><span>10h45 às 11h00</span> <br>Caso Clínico de doença de alto risco no idoso</h4>
                  <p>Palestrante: </p>
                  <h4><span>11h00 às 11h15</span> <br>Caso Clínico de doença metastática</h4>
                  <p>Palestrante: </p>
                  <h4><span>11h15 às 11h30</span> <br>Discussão </h4>
                  <p></p>
                  <h4><span>11h30 às 11h45</span> <br>Caso Clínico de doença localizada de pequeno volume-baixo risco</h4>
                  <p>Palestrante: </p>
                  <h4><span>11h45 às 12h00</span> <br>Caso Clínico de doença localizada de alto risco</h4>
                  <p>Palestrante: </p>
                  <h4><span>12h00 às 12h15</span> <br>Caso Clínico de doença avançada</h4>
                  <p>Palestrante: </p>
                  <h4><span>12h15 às 12h30</span> <br>Discussão</h4>

                  <h3 class="programacao-conteudo-h3-intervalo">12h30 - Encerramento</h3>

                </div>
                <!-- BLOCO Quinta-feira, 25 de novembro - Sala 01 -->


                <!-- BLOCO Quinta-feira, 25 de novembro - Sala 02 -->
                <div class="programacao-bloco">

                  <h2>25 de novembro <span>Sala 02</span></h2>

                  <h3 class="programacao-conteudo-h3-titulo">8h00 às 10h00 - Sarcoma/Melanoma</h3>

                  <h4><span>8h00 às 8h35</span> <br>Melanoma localmente avançado</h4>
                  <p>Palestrante: A definir</p>
                  <h4><span>8h40 às 9h15</span> <br>Melanoma avançado</h4>
                  <p>Palestrante: A definir</p>
                  <h4><span>9h20 às 10h00</span> <br>CEC localmente avançado</h4>
                  <p>Palestrante: A definir</p>

                  <h3 class="programacao-conteudo-h3-intervalo">10h00 às 10h30 – Intervalo</h3>

                  <h3 class="programacao-conteudo-h3-titulo">10h30 às 12h30 - Cabeça e pescoço</h3>
                  <h4><span>10h30 às 10h45</span> <br>Molecular</h4>
                  <p>Palestrante: </p>
                  <h4><span>10h45 às 11h15</span> <br>Imunoterapia e potenciais alvos moleculares</h4>
                  <p>Palestrante: Guilherme Avanço</p>
                  <h4><span>11h15 às 11h30</span> <br>Esvaziamento cervical</h4>
                  <p>Palestrante: Alexandre Bezerra</p>
                  <h4><span>11h30 às 12h00</span> <br>Radioterapia desintensificação HPV positivo</h4>
                  <p>Palestrante: Paula Prati</p>
                  <h4><span>12h00 às 12h30</span> <br>Discussão</h4>

                  <h3 class="programacao-conteudo-h3-intervalo">12h30 - Encerramento</h3>

                </div>
                <!-- BLOCO Quinta-feira, 25 de novembro - Sala 02 -->


                <!-- BLOCO Quinta-feira, 25 de novembro - Sala 03 -->
                <div class="programacao-bloco">

                  <h2>25 de novembro <span>Sala 03</span></h2>

                  <h3 class="programacao-conteudo-h3-titulo">8h00 às 10h00 - Linfomas</h3>
                  <h4><span>8h00 às 8h30</span> <br>Biespecíficos e monoclonais em linfoma não Hodgkin</h4>
                  <p>Palestrante: </p>
                  <h4><span>8h30 às 9h00</span> <br>CAR T em Linfoma não Hodgkin</h4>
                  <p>Palestrante: </p>
                  <h4><span>9h00 às 9h30</span> <br>Anti CD30 e anti PD1 em Linfoma de Hodgkin</h4>
                  <p>Palestrante: </p>
                  <h4><span>9h30 às 10h00</span> <br>Discussão</h4>
                  <p>Palestrante: Celso Arrais</p>

                  <h3 class="programacao-conteudo-h3-intervalo">10h00 às 10h30 - Intervalo</h3>

                  <h3 class="programacao-conteudo-h3-titulo">10h30 às 12h30 - Mieloma</h3>
                  <h4><span>10h30 às 11h00</span> <br>Biespecíficos em Mieloma Múltiplo</h4>
                  <p>Palestrante: </p>
                  <h4><span>11h00 às 11h30</span> <br>CAR T em Mieloma Múltiplo</h4>
                  <p>Palestrante: </p>
                  <h4><span>11h30 às 12h00</span> <br>Mieloma Múltiplo 1a Linha - Por onde começar?</h4>
                  <p>Palestrante:</p>
                  <h4><span>12h00 às 12h30</span> <br>Discussão</h4>
                  <p>Daniel Tabak</p>

                  <h3 class="programacao-conteudo-h3-intervalo">12h30 - Encerramento</h3>

                </div>
                <!-- BLOCO Quinta-feira, 25 de novembro - Sala 03 -->




              </content>
            </li>

          </ul>
        </div>


        <!-- TABS -->

      </div>
    </div>

    <?php include 'inc/hotel-capa.php' ?>
  </content>
    <?php include 'inc/footer.php' ?>
  <script src="assets/js/jquery.min.js"></script>
  <script src="assets/js/scroll-out.js"></script>
  <script src="assets/js/scripts.js"></script>
</body>
</html>















 


