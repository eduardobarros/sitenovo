    <div class="ancora" id="pilares"></div>
    <section class="pilares">
      <h2>Pilares do Compliance</h2>
      <img src="assets/img/pilares-img-mobile.svg" class="pilares-img-mobile pilares-img" title="Pilares do Compliance" loading="lazy">
      <img src="assets/img/pilares-img-desktop.svg" class="pilares-img-desktop pilares-img" title="Pilares do Compliance" loading="lazy">
    </section>