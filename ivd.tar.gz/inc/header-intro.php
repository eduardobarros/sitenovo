    <section class="header-intro">
      <div class="header-intro-degrade"></div>
      <div class="header-intro-degrade-top"></div>
      <img src="assets/img/header-intro-mobile.webp" loading="lazy" class="header-intro-img-mobile" alt="Índice de Valor Dasa">
      <img src="assets/img/header-intro-desktop.webp" loading="lazy" class="header-intro-img-desktop" alt="Índice de Valor Dasa">
      <div class="header-intro-textos">
        <h1>Índice de Valor Dasa</h1>
        <p>Criado para ser uma referência em Qualidade, Eficiência e Segurança para o mercado de saúde brasileiro.</p>
        <a href="#construcao" title="Saiba mais" class="header-intro-seta"><img src="assets/img/seta-branca.svg" alt="Saiva mais"></a>
      </div>
    </section>