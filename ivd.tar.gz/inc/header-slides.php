  <section class="header-slides">
    <div class="header-slide-degrade"></div>
    <div class="slide-topo-textos">
      <h1>Compliance na Dasa</h1>

      <div class="sp-container">
        <div class="sp-content">
          <p class="sp-box sp-frame-1 sp-frase">O compliance sou eu, é você. É um compromisso de cada um de nós com a ética, integridade, transparência e sustentabilidade.</p>
          <p class="sp-box sp-frame-2 sp-texto">O comprometimento com a ética e integridade é exigido de todos os colaboradores, administradores, terceiros e clientes que se relacionam com a Dasa e deve estar presente no nosso dia a dia, na condução dos negócios e em cada tomada de decisão alinhado ao nosso propósito de ser a saúde que as pessoas desejam e que o mundo precisa.</p>
        </div>
      </div>


      <!-- p>O comprometimento com a ética e integridade é exigido de todos os colaboradores, administradores, terceiros e clientes que se relacionam com a Dasa e deve estar presente no nosso dia a dia, na condução dos negócios e em cada tomada de decisão alinhado ao nosso propósito de ser a saúde que as pessoas desejam e que o mundo precisa.</p -->
      <a href="#palavra-dos-presidentes" class="slide-topo-seta" title="Saiba mais"><img src="assets/img/seta-branca.svg" alt="Saiva mais"></a>
    </div>

    <div class="header-slide" id="header-slide" data-flickity='{ "fade": true, "loop": true, "autoPlay": 3000, "draggable": true, "pauseAutoPlayOnHover": false, "pauseAutoPlayOnClick": false, "adaptiveHeight": true }'>
      <div class="header-slide-item" style="background-image: url(assets/img/slide01.webp);">
        <div class="header-slide-item-bg"></div>
        <div class="header-slide-item-degrade"></div>
      </div>
      <div class="header-slide-item" style="background-image: url(assets/img/slide02.webp);">
        <div class="header-slide-item-bg"></div>
        <div class="header-slide-item-degrade"></div>
      </div>
      <div class="header-slide-item" style="background-image: url(assets/img/slide03.webp);">
        <div class="header-slide-item-bg"></div>
        <div class="header-slide-item-degrade"></div>
      </div>
      <div class="header-slide-item" style="background-image: url(assets/img/slide04.webp);">
        <div class="header-slide-item-bg"></div>
        <div class="header-slide-item-degrade"></div>
      </div>
      <div class="header-slide-item" style="background-image: url(assets/img/slide05.webp);">
        <div class="header-slide-item-bg"></div>
        <div class="header-slide-item-degrade"></div>
      </div>
      <div class="header-slide-item" style="background-image: url(assets/img/slide06.webp);">
        <div class="header-slide-item-bg"></div>
        <div class="header-slide-item-degrade"></div>
      </div>
    </div>

  </section>