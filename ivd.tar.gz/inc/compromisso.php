    <div class="ancora" id="compromisso-publico"></div>
    <section class="referencias compromisso">
      <img src="assets/img/compromisso-mobile.webp" title="Pesquisa" class="referencias-mobile referencias-foto" loading="lazy">
      <img src="assets/img/compromisso-desktop.webp" title="Pesquisa" class="referencias-desktop referencias-foto" loading="lazy">
      <div class="referencias-textos">
        <p class="secao-titulo">Compromisso Público</p>
        <h2>Ser reconhecida como uma rede de saúde integrada de maior Qualidade, Eficiência e Segurança.</h2>
        <p class="secao-subtitulo">Estes três conceitos definem a estratégia de desenvolvimento e implementação do Índice de Valor Dasa.</p>
        <div class="referencias-texto">
          <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Curabitur ac semper ipsum, vel eleifend tortor. Phasellus vitae est ac magna vehicula varius at ut sem. Morbi suscipit quam et diam pellentesque mollis. Sed eget ante consequat, mollis libero ac, fermentum sem. </p>
          <p>Vivamus laoreet scelerisque neque vel vestibulum. Suspendisse potenti. Mauris commodo bibendum sapien, vitae tincidunt quam luctus quis. Nulla facilisi. Aenean fermentum, turpis non faucibus elementum, tortor elit aliquam enim, id volutpat nibh tellus at neque. Duis a ante eros. Morbi feugiat lorem non mattis consectetur. Cras dapibus luctus tristique.</p>
          <p>Aenean odio purus, porta a pretium ut, maximus in leo. Morbi in eros in quam rutrum lacinia. Quisque id enim eleifend lectus laoreet facilisis vitae et leo. Aliquam eu suscipit augue. Praesent imperdiet lacinia volutpat.</p>
        </div>
      </div>
    </section>