    <div class="ancora" id="construcao"></div>
    <section class="construcao">
      <div class="construcao-video"></div>
      <div class="construcao-textos">
        <p class="secao-titulo">Construção</p>
        <h2>De uma rede de medicina diagnóstica a um dos mais importantes players do setor de saúde na América Latina</h2>
        <div class="construcao-texto">
          <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Curabitur ac semper ipsum, vel eleifend tortor. Phasellus vitae est ac magna vehicula varius at ut sem. Morbi suscipit quam et diam pellentesque mollis. Sed eget ante consequat, mollis libero ac, fermentum sem. </p>
          <p>Vivamus laoreet scelerisque neque vel vestibulum. Suspendisse potenti. Mauris commodo bibendum sapien, vitae tincidunt quam luctus quis. Nulla facilisi. Aenean fermentum, turpis non faucibus elementum, tortor elit aliquam enim, id volutpat nibh tellus at neque. Duis a ante eros. Morbi feugiat lorem non mattis consectetur. Cras dapibus luctus tristique.</p>
          <p>Aenean odio purus, porta a pretium ut, maximus in leo. Morbi in eros in quam rutrum lacinia. Quisque id enim eleifend lectus laoreet facilisis vitae et leo. Aliquam eu suscipit augue. Praesent imperdiet lacinia volutpat.</p>
        </div>
        <div class="construcao-profissionais">
          <p><span>Pedro de Godoy Bueno</span> Presidente</p>
        </div>
      </div>
    </section>