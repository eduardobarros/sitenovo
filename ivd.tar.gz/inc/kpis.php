    <div class="ancora" id="kpis"></div>
    <section class="indicadores">
      <p class="secao-titulo">Key Performance Indicator</p>
      <h2 class="indicadores-titulo">Conheça nossos indicadores de desempenho</h2>

      <div class="faq">

        <div class="faq-item faq-item1">
          <input type="checkbox" id="question1" name="q" class="questions">
          <div class="plus">+</div>
          <label for="question1" class="question">Lorem ipsum sit amet</label>
          <div class="answers">
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Curabitur ac semper ipsum, vel eleifend tortor. Phasellus vitae est ac magna vehicula varius at ut sem. Morbi suscipit quam et diam pellentesque mollis. Sed eget ante consequat, mollis libero ac, fermentum sem. </p>
            <p>Vivamus laoreet scelerisque neque vel vestibulum. Suspendisse potenti. Mauris commodo bibendum sapien, vitae tincidunt quam luctus quis. Nulla facilisi. Aenean fermentum, turpis non faucibus elementum, tortor elit aliquam enim, id volutpat nibh tellus at neque. </p>
            <p>Duis a ante eros. Morbi feugiat lorem non mattis consectetur. Cras dapibus luctus tristique.</p>          </div>
          </div>
        </div>

        <div class="faq-item faq-item2">
          <input type="checkbox" id="question2" name="q" class="questions">
          <div class="plus">+</div>
          <label for="question2" class="question">Lorem ipsum sit amet</label>
          <div class="answers">
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Curabitur ac semper ipsum, vel eleifend tortor. Phasellus vitae est ac magna vehicula varius at ut sem. Morbi suscipit quam et diam pellentesque mollis. Sed eget ante consequat, mollis libero ac, fermentum sem. </p>
            <p>Vivamus laoreet scelerisque neque vel vestibulum. Suspendisse potenti. Mauris commodo bibendum sapien, vitae tincidunt quam luctus quis. Nulla facilisi. Aenean fermentum, turpis non faucibus elementum, tortor elit aliquam enim, id volutpat nibh tellus at neque. </p>
            <p>Duis a ante eros. Morbi feugiat lorem non mattis consectetur. Cras dapibus luctus tristique.</p>          </div>
          </div>
        </div>

        <div class="faq-item faq-item3">
          <input type="checkbox" id="question3" name="q" class="questions">
          <div class="plus">+</div>
          <label for="question3" class="question">Lorem ipsum sit amet</label>
          <div class="answers">
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Curabitur ac semper ipsum, vel eleifend tortor. Phasellus vitae est ac magna vehicula varius at ut sem. Morbi suscipit quam et diam pellentesque mollis. Sed eget ante consequat, mollis libero ac, fermentum sem. </p>
            <p>Vivamus laoreet scelerisque neque vel vestibulum. Suspendisse potenti. Mauris commodo bibendum sapien, vitae tincidunt quam luctus quis. Nulla facilisi. Aenean fermentum, turpis non faucibus elementum, tortor elit aliquam enim, id volutpat nibh tellus at neque. </p>
            <p>Duis a ante eros. Morbi feugiat lorem non mattis consectetur. Cras dapibus luctus tristique.</p>          </div>
        </div>

      </div>

      <div class="indicadores-download">

        <p class="indicadores-texto">Faça o download de nossos indicadores</p>
        <a href="#" title="Download IVD" class="botao">Download</a>

      </div>


    </section>







