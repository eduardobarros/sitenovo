  <header class="header-menu" id="header-menu">

    <img src="assets/img/dasa-branco.svg" alt="Dasa" class="header-dasa">
    <img src="assets/img/icone-menu.svg" alt="Menu" class="icone-menu">

    <nav class="nav-mobile">
      <a href="#construcao" class="nav-link" title="Construção">Construção</a>
      <a href="#referencias-internacionais" class="nav-link" title="Referências Internacionais">Referências Internacionais</a>
      <a href="#avaliacao" class="nav-link" title="Avaliação Vertical">Avaliação Vertical</a>
      <a href="#kpis" class="nav-link" title="KPIs">KPIs</a>
      <a href="#ivd" class="nav-link" title="Índice de Valor Dasa">IVD</a>
      <a href="#compromisso-publico" class="nav-link" title="Compromisso Público">Compromisso Público</a>
      <a href="#downloads" class="nav-link" title="Downloads">Downloads</a>
    </nav>

    <nav class="nav-desktop">
      <a href="#construcao" class="nav-link-desktop" title="Construção">Construção</a>
      <a href="#referencias-internacionais" class="nav-link-desktop" title="Referências Internacionais">Referências Internacionais</a>
      <a href="#avaliacao" class="nav-link-desktop" title="Avaliação Vertical">Avaliação Vertical</a>
      <a href="#kpis" class="nav-link-desktop" title="KPIs">KPIs</a>
      <a href="#ivd" class="nav-link-desktop" title="Índice de Valor Dasa">IVD</a>
      <a href="#compromisso-publico" class="nav-link-desktop" title="Compromisso Público">Compromisso Público</a>
      <a href="#downloads" class="nav-link-desktop" title="Downloads">Downloads</a>
    </nav>
    
  </header>