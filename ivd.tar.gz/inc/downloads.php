    <div class="ancora" id="downloads"></div>
    <section class="downloads">
      <div class="downloads-textos">
        <p class="secao-titulo">Downloads</p>
        <h2>Consulte e faça o download dos Relatórios IVD</h2>
        <p class="downloads-intro">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Curabitur ac semper ipsum, vel eleifend tortor. Phasellus vitae est ac magna vehicula varius at ut sem. </p>
        <p class="downloads-conheca"><br><b>Clique para baoixar os relatórios IVD.</b></p>
      </div>
      <div class="downloads-botoes">
        <a href="#" title="Lorem ipsum dolor sit amet" target="_blank">Lorem ipsum dolor sit amet <img src="assets/img/icone-download.svg" alt="Relatório IVD"></a>
        <a href="#" title="Lorem ipsum dolor sit amet" target="_blank">Lorem ipsum dolor sit amet <img src="assets/img/icone-download.svg" alt="Relatório IVD"></a>
        <a href="#" title="Lorem ipsum dolor sit amet" target="_blank">Lorem ipsum dolor sit amet <img src="assets/img/icone-download.svg" alt="Relatório IVD"></a>
      </div>
    </section>