    <div class="ancora" id="referencias-internacionais"></div>
    <section class="referencias">
      <img src="assets/img/referencias-mobile.webp" title="Pesquisa" class="referencias-mobile referencias-foto" loading="lazy">
      <img src="assets/img/referencias-desktop.webp" title="Pesquisa" class="referencias-desktop referencias-foto" loading="lazy">
      <div class="referencias-textos">
        <p class="secao-titulo">Referências Internacionais</p>
        <h2>Parceria internacional com a maior referência global em qualidade na área da saúde</h2>
        <div class="referencias-texto">
          <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Curabitur ac semper ipsum, vel eleifend tortor. Phasellus vitae est ac magna vehicula varius at ut sem. Morbi suscipit quam et diam pellentesque mollis. Sed eget ante consequat, mollis libero ac, fermentum sem. </p>
          <p>Vivamus laoreet scelerisque neque vel vestibulum. Suspendisse potenti. Mauris commodo bibendum sapien, vitae tincidunt quam luctus quis. Nulla facilisi. Aenean fermentum, turpis non faucibus elementum, tortor elit aliquam enim, id volutpat nibh tellus at neque. Duis a ante eros. Morbi feugiat lorem non mattis consectetur. Cras dapibus luctus tristique.</p>
          <p>Aenean odio purus, porta a pretium ut, maximus in leo. Morbi in eros in quam rutrum lacinia. Quisque id enim eleifend lectus laoreet facilisis vitae et leo. Aliquam eu suscipit augue. Praesent imperdiet lacinia volutpat.</p>
        </div>

        <!-- LISTA COM CHECKBOX + BOTÃO
        <ul>
          <li><img src="assets/img/check-vermelho.svg" alt="Check"> O Canal de Conduta é uma ferramenta sigilosa que possibilita a qualquer pessoa, interna ou externa à Companhia, realizar denúncias, de forma anônima ou não. É o local onde deve ser reportado suspeitas de comportamentos indevidos ou posturas que violem os Códigos de Conduta e as Políticas Internas ou as leis vigentes para que sejam devidamente investigadas. </li>
          <li><img src="assets/img/check-vermelho.svg" alt="Check"> Não permitimos e não toleramos a retaliação contra denunciantes de boa-fé. </li>
        </ul>
        <a href="https://www.canaldaconduta.com.br/" target="_blank" title="Acessar Canal de Conduta" class="botao">Acessar Canal de Conduta</a>
        -->

      </div>
    </section>