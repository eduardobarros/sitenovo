    <div class="ancora" id="estrutura"></div>
    <section class="estrutura">
      <div class="estrutura-textos">
        <h2>Estrutura</h2>
        <div class="estrutura-texto">
          <p style="color: #A6E1FF;">A Dasa possui uma área dedicada à condução das atividades de Compliance. Esta área é independente da Diretoria Executiva e tem reporte ao Compliance Officer, o qual reporta-se diretamente ao Conselho de Administração. </p>
          <p>A área conta com um Comitê Executivo de Integridade formado por executivos seniores da Companhia, que supervisiona e acompanha periodicamente os temas relacionados ao Canal de Conduta.</p>
          <p>O Comitê de Auditoria da Dasa, Controles Internos/ Auditoria Interna e Externa também acompanham e auditam as ações de Compliance .</p>
          <p>Para entrar em contato com a área de Compliance, envie um e-mail para compliance@dasa.com.br</p>
        </div>
      </div>
      <img src="assets/img/estrutura-img-mobile.svg" class="estrutura-img-mobile estrutura-img" alt="Estrutura Dasa Compliance" loading="lazy">
      <img src="assets/img/estrutura-img-desktop.svg" class="estrutura-img-desktop estrutura-img" alt="Estrutura Dasa Compliance" loading="lazy">
    </section>