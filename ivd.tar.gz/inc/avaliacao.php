    <div class="ancora" id="avaliacao"></div>
    <section class="avaliacao">
      <div class="avaliacao-img">
        <img src="assets/img/avaliacao.webp" alt="Avaliação">
      </div>
      <div class="avaliacao-textos">
        <p class="secao-titulo">Avaliação Vertical</p>
        <h2>Integrações operacionais para todas unidades</h2>
        <p class="secao-subtitulo">Um único drive de business management, uma única cultura, uma mesma comunicação.</p>
        <div class="avaliacao-texto">
          <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Curabitur ac semper ipsum, vel eleifend tortor. Phasellus vitae est ac magna vehicula varius at ut sem. Morbi suscipit quam et diam pellentesque mollis. Sed eget ante consequat, mollis libero ac, fermentum sem. Cras dapibus luctus tristique.</p>
          <p>Vivamus laoreet scelerisque neque vel vestibulum. Suspendisse potenti. Mauris commodo bibendum sapien, vitae tincidunt quam luctus quis. Nulla facilisi. Aenean fermentum, turpis non faucibus elementum, tortor elit aliquam enim, id volutpat nibh tellus at neque. Morbi feugiat lorem non consectetur.</p>
        </div>
      </div>
    </section>