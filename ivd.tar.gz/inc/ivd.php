    <div class="ancora" id="ivd"></div>
    <section class="ivd">
      <img src="assets/img/ivd.svg" class="ivd-img" title="ivd" loading="lazy">
      <div class="ivd-textos">
        <p class="secao-titulo">ÍNDICE DE VALOR DASA</p>
        <h2>O paciente é a razão para a criação do Índice de Valor Dasa</h2>
        <p class="secao-subtitulo">O IVD é o comprometimento que a companhia tem com  de pessoas que buscam atendimento anualmente em suas unidades de negócios. </p>
        <div class="ivd-texto">
          <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Curabitur ac semper ipsum, vel eleifend tortor. Phasellus vitae est ac magna vehicula varius at ut sem. Morbi suscipit quam et diam pellentesque mollis. Sed eget ante consequat, mollis libero ac, fermentum sem. </p>
          <p>Vivamus laoreet scelerisque neque vel vestibulum. Suspendisse potenti. Mauris commodo bibendum sapien, vitae tincidunt quam luctus quis. Nulla facilisi. Aenean fermentum, turpis non faucibus elementum, tortor elit aliquam enim, id volutpat nibh tellus at neque. Duis a ante eros. Morbi feugiat lorem non mattis consectetur. Cras dapibus luctus tristique.</p>
          <p>Aenean odio purus, porta a pretium ut, maximus in leo. Morbi in eros in quam rutrum lacinia. Quisque id enim eleifend lectus laoreet facilisis vitae et leo. Aliquam eu suscipit augue. Praesent imperdiet lacinia volutpat.</p>
        </div>
        <a href="#" target="_blank" class="botao" title="Download e-book IDV">Download e-book IDV</a>
      </div>
    </section>