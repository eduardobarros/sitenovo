  <section class="header-slides">
    <!-- div class="header-slide-degrade"></div -->
    <!-- div class="slide-topo-textos">
      <h1>Compliance na Dasa</h1>
      <p>O comprometimento com a ética e integridade é exigido de todos os colaboradores, administradores, terceiros e clientes que se relacionam com a Dasa e deve estar presente no nosso dia a dia, na condução dos negócios e em cada tomada de decisão alinhado ao nosso propósito de ser a saúde que as pessoas desejam e que o mundo precisa.</p >
      <a href="#palavra-dos-presidentes" class="slide-topo-seta" title="Saiba mais"><img src="assets/img/seta-branca.svg" alt="Saiva mais"></a>
    </div -->

    <div class="header-slide" id="header-slide" data-flickity='{ "loop": true, "autoPlay": 5000, "draggable": true, "pauseAutoPlayOnHover": false, "pauseAutoPlayOnClick": false, "adaptiveHeight": true }'>
      <div class="header-slide-item" style="background: #F7F7F7; color: #000F40">
        <p style="display: flex; align-items: center; justify-content: center; width: 80%; height: 70%; margin: auto; border: 4px solid #DDD; border-radius: 10px;">Slide 01</p>
        <div class="header-slide-item-bg"></div>
        <!-- div class="header-slide-item-degrade"></div -->
      </div>
      <div class="header-slide-item" style="background: #000F40; color: white;">
        <p style="display: flex; align-items: center; justify-content: center; width: 80%; height: 70%; margin: auto; border: 4px solid rgba(255, 255, 255, .2); border-radius: 10px;">Slide 02</p>
        <div class="header-slide-item-bg"></div>
        <!-- div class="header-slide-item-degrade"></div -->
      </div>
      <div class="header-slide-item" style="background: #D1B287; color: white;">
        <p style="display: flex; align-items: center; justify-content: center; width: 80%; height: 70%; margin: auto; border: 4px solid #DDD; border-radius: 10px;">Slide 03</p>
        <div class="header-slide-item-bg"></div>
        <!-- div class="header-slide-item-degrade"></div -->
      </div>
    </div>

  </section>