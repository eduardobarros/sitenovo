    <section class="mensagem">

      <div class="mensagem-textos">
        <h2>Mensagem do Presidente</h2>
        <p>É com grande satisfação que anunciamos o Congresso Dasa Oncologia 2023.  E teremos como tema <b>“Transformação”.</b></p>
        <p>Mais do que <b>inovar</b>, a Dasa traz no seu DNA a busca incansável pela transformação na saúde, marca presente também no nascimento da <b>Dasa Oncologia.</b> De forma presencial, grandes nomes da Oncologia nacional e internacional vão trazer para debate a expertise em <b>prevenção, diagnóstico e tratamento</b> nos mais diversos âmbitos. </p>
        <p>E como a oncologia tem se <b>transformado!</b> O diagnóstico se tornou preciso, molecular, nuclear, personalizado. Cada paciente tem uma apresentação única e as neoplasias têm assinaturas genéticas distintas. Os exames de imagem norteiam o estadiamento e guiam o tipo de intervenção indicada.</p>
        <p>O tratamento hoje pode ser individualizado a ponto de se utilizar cirurgias minimamente invasivas, interativas, radioterapia superprecisa, terapias de alvo molecular e imunoterapia. </p>
        <p>Como não poderia ser diferente, o programa do <b>Congresso Dasa Oncologia 2023</b> também será transformador. Cada mesa terá uma sessão dedicada à inovação, transbordando conhecimento e dissecando as mudanças de conduta. Tudo de forma prática, baseada em casos comuns que se apresentam no nosso dia a dia. Cada sessão foi cuidadosamente desenhada a fim de cobrir todos os avanços relevantes, de forma a impactar positivamente a prática clínica dos participantes.</p>
        <p style="font-size: 24px; text-align:  center; padding: 40px 0; font-family: DasaBold, sans-serif;">Contamos com a sua participação!</p>
      </div>

      <div class="mensagem-personas">

        <h3>Comissão Organizadora</h3>

        <div class="mensagem-persona-itens">
          <div class="mensagem-personas-item">
            <img src="assets/img/personas/dr-luiz-henrique-de-lima-araujo-chair.webp" alt="Dr. Luiz Henrique de Lima Araújo">
            <h5><span class="mensagem-personas-item-cadeira">Presidente do Congresso </span>Dr. Luiz Henrique de Lima Araújo <span>Oncologista Clínico - CRM 797324/RJ <br>Diretor regional da Dasa Oncologia/RJ</span></h5>
          </div>
          <div class="mensagem-personas-item">
            <img src="assets/img/personas/dr-gustavo-fernandes-co-chair.webp" alt="Dr. Gustavo Fernandes">
            <h5><span class="mensagem-personas-item-cadeira">Vice Presidente do Congresso </span>Dr. Gustavo Fernandes <span>Oncologista Clínico e Hematologista - CRM 16558/DF <br>Diretor nacional da Dasa Oncologia</span></h5>
          </div>
        </div>

        <h4 class="mensagem-personas-cadeira"><span>Comissão Executiva</span></h4>

        <div class="mensagem-persona-itens">
          <div class="mensagem-personas-item">
            <img src="assets/img/personas/dra-juliana-ominelli.webp" alt="Dra. Juliana Ominelli">
            <h5>Dra. Juliana Ominelli <span>Oncologista Clínica - CRM 52918415/RJ <br>Coordenadora de diagnóstico e navegação da oncologia Dasa/RJ</span></h5>
          </div>
          <div class="mensagem-personas-item">
            <img src="assets/img/personas/dra-mariana-scaranti.webp" alt="Dra. Mariana Scaranti">
            <h5>Dra. Mariana Scaranti <span>Oncologista Clínica - CRM 144409/SP <br>Coordenadora oncologista de tumores ginecológicos da Dasa Oncologia/SP</span></h5>
          </div>
        </div>

      </div>

    </section>