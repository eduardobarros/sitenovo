<!DOCTYPE html>
<html lang="pt-br">
<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <title>Programação - Congresso Dasa Oncologia 2023</title>
  <meta name="description" content="Um evento totalmente voltado para o compartilhamento do conhecimento científico, pensado e organizado detalhadamente para levar aos nossos convidados o que há de mais inovador e moderno sobre os cuidados oncológicos, visando uma medicina preditiva, preventiva e cuidar sempre e por inteiro." />
  <meta name="robots" content="noindex">

  <meta property="og:title" content="Congresso Dasa Oncologia 2023" />
  <meta property="og:site_name" content="Dasa" />
  <meta property="og:description" content="Um evento totalmente voltado para o compartilhamento do conhecimento científico, pensado e organizado detalhadamente para levar aos nossos convidados o que há de mais inovador e moderno sobre os cuidados oncológicos, visando uma medicina preditiva, preventiva e cuidar sempre e por inteiro.">

  <meta property="og:type" content="website">
  <meta property="og:locale" content="pt-br" />

  <meta property="og:image" content="https://placcopazzinidev09.com.br/assets/img/og.jpg">
  <meta property="og:image:type" content="image/jpg">
  <meta property="og:image:width" content="1200">
  <meta property="og:image:height" content="630">

  <meta property="twitter:title" content="Congresso Dasa Oncologia 2023" />
  <meta property="twitter:description" content="O Programa de Compliance da Dasa é uma ferramenta de todos a quem ele se aplica e consolida o conjunto de medidas institucionais para o desenvolvimento de suas atividades de forma ética e íntegra." />
  <meta property="twitter:image" content="https://placcopazzinidev09.com.br/assets/img/og.jpg" />

  <link rel="icon" type="image/png" href="assets/img/favicon.png">
  <link rel="shortcut icon" href="assets/img/favicon.png" />

  <!-- PRELOAD -->
  <link rel="preload" as="style" href="assets/css/main.css" >
  <link rel="preload" as="script" href="assets/js/jquery.min.js">
  <link rel="preload" as="script" href="assets/js/scroll-out.js">
  <link rel="preload" as="script" href="assets/js/scripts.js">

  <link rel="preload" as="image" src="assets/img/slide01.webp" >
  <link rel="preload" as="image" src="assets/img/slide02.webp" >
  <link rel="preload" as="image" src="assets/img/slide03.webp" >
  <link rel="preload" as="image" src="assets/img/slide04.webp" >
  <link rel="preload" as="image" src="assets/img/slide05.webp" >

  <link rel="stylesheet" href="assets/css/main.css">
  <link rel="stylesheet" href="assets/css/flickity-docs.css">

</head>
<body>

  <?php include 'inc/header.php' ?>
  <content>

    <div class="breadcrumb">Programação do evento</div>

    <div class="conteudo">
      <h1>Programação do Congresso Dasa Oncologia</h1>
        <div class="conteudo-textos conteudo-programacao">

        <!--- DIA --->  
        <h2>Dia 00/00</h2>

        <h3>Programação 01</h3>
        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec venenatis accumsan quam eget commodo. Etiam id urna ultricies, auctor enim a, feugiat nisl. Mauris molestie, ante sit amet rhoncus interdum, nisi est pellentesque orci, sed feugiat nulla nibh quis massa. Mauris nibh lacus, pulvinar eu elit ut, mollis finibus est.</p>
        <p class="conteudo-palestrante-bold">Palestrante(s):</p>
        <div class="conteudo-palestrante">
          <img src="assets/img/personas/dr-gustavo-fernandes-co-chair.webp" alt="Dr. Gustavo Fernandes">
          <h4>Dr. Gustavo Fernandes <span>Oncologista Clínico e Hematologista</span></h4>
        </div>
        <p class="conteudo-palestrante-bold">Conteúdo:</p>
        <ul>
          <li>Ginecologia</li>
          <li>Saúde da mulher em oncologia</li>
          <li>Imagem em oncologia</li>
          <li>Tumores do sistema nervoso central</li>
          <li>Cardio-oncologia</li>
          <li>Geniturinário </li>
          <li>Sarcoma/Melanoma</li>
          <li>Cabeça e Pescoço</li>
          <li>Hematologia </li>
          <li>Experiência do paciente</li>
        </ul>

        <h3>Programação 02</h3>
        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec venenatis accumsan quam eget commodo. Etiam id urna ultricies, auctor enim a, feugiat nisl. Mauris molestie, ante sit amet rhoncus interdum, nisi est pellentesque orci, sed feugiat nulla nibh quis massa. Mauris nibh lacus, pulvinar eu elit ut, mollis finibus est.</p>
        <p class="conteudo-palestrante-bold">Palestrante(s):</p>
        <div class="conteudo-palestrante">
          <img src="assets/img/personas/dr-gustavo-fernandes-co-chair.webp" alt="Dr. Gustavo Fernandes">
          <h4>Dr. Gustavo Fernandes <span>Oncologista Clínico e Hematologista</span></h4>
        </div>
        <p class="conteudo-palestrante-bold">Conteúdo:</p>
        <ul>
          <li>Ginecologia</li>
          <li>Saúde da mulher em oncologia</li>
          <li>Imagem em oncologia</li>
          <li>Tumores do sistema nervoso central</li>
          <li>Cardio-oncologia</li>
          <li>Geniturinário </li>
          <li>Sarcoma/Melanoma</li>
          <li>Cabeça e Pescoço</li>
          <li>Hematologia </li>
          <li>Experiência do paciente</li>
        </ul>


        <!--- DIA --->  
        <h2>Dia 00/00</h2>

        <h3>Programação 03</h3>
        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec venenatis accumsan quam eget commodo. Etiam id urna ultricies, auctor enim a, feugiat nisl. Mauris molestie, ante sit amet rhoncus interdum, nisi est pellentesque orci, sed feugiat nulla nibh quis massa. Mauris nibh lacus, pulvinar eu elit ut, mollis finibus est.</p>
        <p class="conteudo-palestrante-bold">Palestrante(s):</p>
        <div class="conteudo-palestrante">
          <img src="assets/img/personas/dr-gustavo-fernandes-co-chair.webp" alt="Dr. Gustavo Fernandes">
          <h4>Dr. Gustavo Fernandes <span>Oncologista Clínico e Hematologista</span></h4>
        </div>
        <p class="conteudo-palestrante-bold">Conteúdo:</p>
        <ul>
          <li>Ginecologia</li>
          <li>Saúde da mulher em oncologia</li>
          <li>Imagem em oncologia</li>
          <li>Tumores do sistema nervoso central</li>
          <li>Cardio-oncologia</li>
          <li>Geniturinário </li>
          <li>Sarcoma/Melanoma</li>
          <li>Cabeça e Pescoço</li>
          <li>Hematologia </li>
          <li>Experiência do paciente</li>
        </ul>

        <h3>Programação 04</h3>
        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec venenatis accumsan quam eget commodo. Etiam id urna ultricies, auctor enim a, feugiat nisl. Mauris molestie, ante sit amet rhoncus interdum, nisi est pellentesque orci, sed feugiat nulla nibh quis massa. Mauris nibh lacus, pulvinar eu elit ut, mollis finibus est.</p>
        <p class="conteudo-palestrante-bold">Palestrante(s):</p>
        <div class="conteudo-palestrante">
          <img src="assets/img/personas/dr-gustavo-fernandes-co-chair.webp" alt="Dr. Gustavo Fernandes">
          <h4>Dr. Gustavo Fernandes <span>Oncologista Clínico e Hematologista</span></h4>
        </div>
        <p class="conteudo-palestrante-bold">Conteúdo:</p>
        <ul>
          <li>Ginecologia</li>
          <li>Saúde da mulher em oncologia</li>
          <li>Imagem em oncologia</li>
          <li>Tumores do sistema nervoso central</li>
          <li>Cardio-oncologia</li>
          <li>Geniturinário </li>
          <li>Sarcoma/Melanoma</li>
          <li>Cabeça e Pescoço</li>
          <li>Hematologia </li>
          <li>Experiência do paciente</li>
        </ul>

      </div>
    </div>

    <?php include 'inc/hotel-capa.php' ?>
  </content>
    <?php include 'inc/footer.php' ?>
  <script src="assets/js/jquery.min.js"></script>
  <script src="assets/js/scroll-out.js"></script>
  <script src="assets/js/scripts.js"></script>
</body>
</html>