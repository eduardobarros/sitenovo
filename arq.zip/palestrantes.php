<!DOCTYPE html>
<html lang="pt-br">
<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <title>Patrocinadores - Congresso Dasa Oncologia 2023</title>
  <meta name="description" content="Um evento totalmente voltado para o compartilhamento do conhecimento científico, pensado e organizado detalhadamente para levar aos nossos convidados o que há de mais inovador e moderno sobre os cuidados oncológicos, visando uma medicina preditiva, preventiva e cuidar sempre e por inteiro." />
  <meta name="robots" content="noindex">

  <meta property="og:title" content="Congresso Dasa Oncologia 2023" />
  <meta property="og:site_name" content="Dasa" />
  <meta property="og:description" content="Um evento totalmente voltado para o compartilhamento do conhecimento científico, pensado e organizado detalhadamente para levar aos nossos convidados o que há de mais inovador e moderno sobre os cuidados oncológicos, visando uma medicina preditiva, preventiva e cuidar sempre e por inteiro.">

  <meta property="og:type" content="website">
  <meta property="og:locale" content="pt-br" />

  <meta property="og:image" content="https://placcopazzinidev09.com.br/assets/img/og.jpg">
  <meta property="og:image:type" content="image/jpg">
  <meta property="og:image:width" content="1200">
  <meta property="og:image:height" content="630">

  <meta property="twitter:title" content="Congresso Dasa Oncologia 2023" />
  <meta property="twitter:description" content="O Programa de Compliance da Dasa é uma ferramenta de todos a quem ele se aplica e consolida o conjunto de medidas institucionais para o desenvolvimento de suas atividades de forma ética e íntegra." />
  <meta property="twitter:image" content="https://placcopazzinidev09.com.br/assets/img/og.jpg" />

  <link rel="icon" type="image/png" href="assets/img/favicon.png">
  <link rel="shortcut icon" href="assets/img/favicon.png" />

  <!-- PRELOAD -->
  <link rel="preload" as="style" href="assets/css/main.css" >
  <link rel="preload" as="style" href="assets/css/flickity-docs.css" >
  <link rel="preload" as="script" href="assets/js/jquery.min.js">
  <link rel="preload" as="script" href="assets/js/scroll-out.js">
  <link rel="preload" as="script" href="assets/js/scripts.js">

  <link rel="preload" as="image" src="assets/img/slide01.webp" >
  <link rel="preload" as="image" src="assets/img/slide02.webp" >
  <link rel="preload" as="image" src="assets/img/slide03.webp" >
  <link rel="preload" as="image" src="assets/img/slide04.webp" >
  <link rel="preload" as="image" src="assets/img/slide05.webp" >

  <link rel="stylesheet" href="assets/css/main.css">
  <link rel="stylesheet" href="assets/css/flickity-docs.css">

</head>
<body>

  <?php include 'inc/header.php' ?>
  <content>

    <div class="breadcrumb">Palestrantes</div>

    <div class="conteudo conteudo-palestrantes-lista">
      <h1>Palestrantes do Congresso Dasa Oncologia</h1>

      <div class="palestrantes-lista">
        
        <div class="palestrantes-conteudo-lista-item" title="Adriana Alves">
          <img src="assets/img/personas/dra-adriana-alves.webp" alt="Adriana Alves">
          <h5>Adriana Alves <span>Diretoria Assistencial de Oncologia Dasa</span></h5>
        </div>
        
        <div class="palestrantes-conteudo-lista-item" title="Dra. Aknar Calabrich">
          <img src="assets/img/personas/dra-aknar-calabrich.webp" alt="Dra. Aknar Calabrich">
          <h5>Dra. Aknar Calabrich <span>Oncologista Clínica<br> CRM 21855/BA</span></h5>
        </div>
        
        <div class="palestrantes-conteudo-lista-item" title="Dra. Anelisa Coutinho">
          <img src="assets/img/personas/dra-anelisa-coutinho.webp" alt="Dra. Anelisa Coutinho">
          <h5>Dra. Anelisa Coutinho <span>Oncologista Clínica<br> CRM 11452/BA</span></h5>
        </div>
        
        <div class="palestrantes-conteudo-lista-item" title="Dr. Augusto Mota">
          <img src="assets/img/personas/dr-augusto-mota.webp" alt="Dr. Augusto Mota">
          <h5>Dr. Augusto Mota <span>Oncologista Clínico<br> CRM 14397 /BA</span></h5>
        </div>
        
        <div class="palestrantes-conteudo-lista-item" title="Dra. Carolina Kawamura">
          <img src="assets/img/personas/dra-carolina-kawamura.webp" alt="Dra. Carolina Kawamura">
          <h5>Dra. Carolina Kawamura <span>Oncologista Clínico <br>CRM 119713/SP</span></h5>
        </div>
        
        <div class="palestrantes-conteudo-lista-item" title="Dra. Caroline Chaul">
          <img src="assets/img/personas/dra-caroline-chaul.webp" alt="Dra. Caroline Chaul">
          <h5>Dra. Caroline Chaul <span>Oncologista Clínica<br> CRM 131520/SP</span></h5>
        </div>
        
        <div class="palestrantes-conteudo-lista-item" title="Dr. Celso Arrais">
          <img src="assets/img/personas/dr-celso-arrais.webp" alt="Dr. Celso Arrais">
          <h5>Dr. Celso Arrais <span>Onco-hematologia<br> CRM 98682/SP</span></h5>
        </div>
        
        <div class="palestrantes-conteudo-lista-item" title="Dr. Fernando Vidigal">
          <img src="assets/img/personas/dr-fernando-vidigal.webp" alt="Dr. Fernando Vidigal">
          <h5>Dr. Fernando Vidigal <span>Oncologista Clínico<br> CRM 22020/DF</span></h5>
        </div>
        
        <div class="palestrantes-conteudo-lista-item" title="Dr. Gustavo Fernandes">
          <img src="assets/img/personas/dr-gustavo-fernandes-co-chair.webp" alt="Dr. Gustavo Fernandes">
          <h5>Dr. Gustavo Fernandes <span>Oncologista Clínico e Hematologista<br> CRM 16558/DF</span></h5>
        </div>
        
        <div class="palestrantes-conteudo-lista-item" title="Dr. Iuri Melo">
          <img src="assets/img/personas/dr-iuri-santana.webp" alt="Dr. Iuri Melo">
          <h5>Dr. Iuri Melo <span>Oncologista Clínico<br> CRM 26191/BA</span></h5>
        </div>
        
        <div class="palestrantes-conteudo-lista-item" title="Dr. Luiz Henrique de Lima Araújo">
          <img src="assets/img/personas/dr-luiz-henrique-de-lima-araujo-chair.webp" alt="Dr. Luiz Henrique de Lima Araújo">
          <h5>Dr. Luiz Henrique de Lima Araújo <span>Oncologista Clínico<br> CRM 797324/RJ</span></h5>
        </div>
        
        <div class="palestrantes-conteudo-lista-item" title="Dr. Marcos Tavares">
          <img src="assets/img/personas/dr-marcos-tavares.webp" alt="Dr. Marcos Tavares">
          <h5>Dr. Marcos Tavares <span>Pneumologista <br>CRM 121046/SP</span></h5>
        </div>
        
        <div class="palestrantes-conteudo-lista-item" title="Dra. Mariana Scaranti">
          <img src="assets/img/personas/dra-mariana-scaranti.webp" alt="Dra. Mariana Scaranti">
          <h5>Dra. Mariana Scaranti <span>Oncologista Clínica<br> CRM 144409/SP</span></h5>
        </div>
        
        <div class="palestrantes-conteudo-lista-item" title="Dr. Romulo Barroso">
          <img src="assets/img/personas/dr-romulo-barroso.webp" alt="Dr. Romulo Barroso">
          <h5>Dr. Romulo Barroso <span>Oncologista Clínico<br> CRM 25325/DF</span></h5>
        </div>
        
        <div class="palestrantes-conteudo-lista-item" title="Dr. Tiago Kenji">
          <img src="assets/img/personas/dr-tiago-kenji.webp" alt="Dr. Tiago Kenji">
          <h5>Dr. Tiago Kenji <span>Oncologista Clínico<br> CRM 125042/SP</span></h5>
        </div>
        
        <div class="palestrantes-conteudo-lista-item" title="Dra. Thamine Lessa">
          <img src="assets/img/personas/dra-thamine-lessa.webp" alt="Dra. Thamine Lessa">
          <h5>Dra. Thamine Lessa <span>Pneumologista<br> CRM 12958/BA</span></h5>
        </div>
        


      </div>

    </div>

  </content>
    <?php include 'inc/footer.php' ?>
  <script src="assets/js/jquery.min.js"></script>
  <script src="assets/js/scroll-out.js"></script>
  <script src="assets/js/scripts.js"></script>
  <script src="assets/js/flickity-docs.min.js"></script>
</body>
</html>