<!DOCTYPE html>
<html lang="pt-br">
<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <title>Patrocinadores - Congresso Dasa Oncologia 2023</title>
  <meta name="description" content="Um evento totalmente voltado para o compartilhamento do conhecimento científico, pensado e organizado detalhadamente para levar aos nossos convidados o que há de mais inovador e moderno sobre os cuidados oncológicos, visando uma medicina preditiva, preventiva e cuidar sempre e por inteiro." />
  <meta name="robots" content="noindex">

  <meta property="og:title" content="Congresso Dasa Oncologia 2023" />
  <meta property="og:site_name" content="Dasa" />
  <meta property="og:description" content="Um evento totalmente voltado para o compartilhamento do conhecimento científico, pensado e organizado detalhadamente para levar aos nossos convidados o que há de mais inovador e moderno sobre os cuidados oncológicos, visando uma medicina preditiva, preventiva e cuidar sempre e por inteiro.">

  <meta property="og:type" content="website">
  <meta property="og:locale" content="pt-br" />

  <meta property="og:image" content="https://placcopazzinidev09.com.br/assets/img/og.jpg">
  <meta property="og:image:type" content="image/jpg">
  <meta property="og:image:width" content="1200">
  <meta property="og:image:height" content="630">

  <meta property="twitter:title" content="Congresso Dasa Oncologia 2023" />
  <meta property="twitter:description" content="O Programa de Compliance da Dasa é uma ferramenta de todos a quem ele se aplica e consolida o conjunto de medidas institucionais para o desenvolvimento de suas atividades de forma ética e íntegra." />
  <meta property="twitter:image" content="https://placcopazzinidev09.com.br/assets/img/og.jpg" />

  <link rel="icon" type="image/png" href="assets/img/favicon.png">
  <link rel="shortcut icon" href="assets/img/favicon.png" />

  <!-- PRELOAD -->
  <link rel="preload" as="style" href="assets/css/main.css" >
  <link rel="preload" as="style" href="assets/css/flickity-docs.css" >
  <link rel="preload" as="script" href="assets/js/jquery.min.js">
  <link rel="preload" as="script" href="assets/js/scroll-out.js">
  <link rel="preload" as="script" href="assets/js/scripts.js">

  <link rel="preload" as="image" src="assets/img/slide01.webp" >
  <link rel="preload" as="image" src="assets/img/slide02.webp" >
  <link rel="preload" as="image" src="assets/img/slide03.webp" >
  <link rel="preload" as="image" src="assets/img/slide04.webp" >
  <link rel="preload" as="image" src="assets/img/slide05.webp" >

  <link rel="stylesheet" href="assets/css/main.css">
  <link rel="stylesheet" href="assets/css/flickity-docs.css">

</head>
<body>

  <?php include 'inc/header.php' ?>
  <content>

    <div class="breadcrumb">Comissão Organizadora</div>

    <div class="conteudo conteudo-palestrantes-lista">

        <div class="mensagem-persona-itens">
          <div class="mensagem-personas-item">
            <img src="assets/img/personas/dr-luiz-henrique-de-lima-araujo-chair.webp" alt="Dr. Luiz Henrique de Lima Araújo">
            <h5 style="color: #000F40 !important;"><span class="mensagem-personas-item-cadeira" style="color: #000F40 !important;">Presidente do Congresso </span>Dr. Luiz Henrique de Lima Araújo <span style="color: #000F40 !important; opacity: 1;">Oncologista Clínico - CRM 797324/RJ <br>Diretor regional da Dasa Oncologia/RJ</span></h5>
          </div>
          <div class="mensagem-personas-item">
            <img src="assets/img/personas/dr-gustavo-fernandes-co-chair.webp" alt="Dr. Gustavo Fernandes">
            <h5 style="color: #000F40 !important;"><span class="mensagem-personas-item-cadeira" style="color: #000F40 !important;">Vice Presidente do Congresso </span>Dr. Gustavo Fernandes <span style="color: #000F40 !important; opacity: 1;">Oncologista Clínico e Hematologista - CRM 16558/DF <br>Diretor nacional da Dasa Oncologia</span></h5>
          </div>
        </div>

      <h2 style="text-align: center; padding: 50px 0 25px 0;">Comissão executiva</h2>

      <div class="palestrantes-lista" style="justify-content: center;">

        <div class="palestrantes-conteudo-lista-item" title="Dra. Dra. Juliana Ominelli">
          <img src="assets/img/personas/dra-juliana-ominelli.webp" alt="Dra. Dra. Juliana Ominelli">
          <h5>Dra. Juliana Ominelli <span>Oncologista Clínica - CRM 52918415/RJ <br>Coordenadora de diagnóstico e navegação da oncologia Dasa/RJ</span></h5>
        </div>

        <div class="palestrantes-conteudo-lista-item" title="Dra. Mariana Scaranti">
          <img src="assets/img/personas/dra-mariana-scaranti.webp" alt="Dra. Mariana Scaranti">
          <h5>Dra. Mariana Scaranti <span>Oncologista Clínica - CRM 144409/SP <br>Coordenadora oncologista de tumores ginecológicos da Dasa Oncologia/SP</span></h5>
        </div>

      </div>
      <h2 style="text-align: center; padding: 50px 0 25px 0;">Comissão científica</h2>






      <div class="palestrantes-lista comissao-cientifica-lista">



        <!-- SINGLE -->
        <div class="palestrantes-conteudo-single">
          <p class="palestrantes-area">Mama</p>
          <div class="palestrantes-conteudo-lista-item" title="Dr. Romualdo Barroso">
            <img src="assets/img/personas/dr-romulo-barroso.webp" alt="Dr. Romualdo Barroso">
            <h5>Dr. Romualdo Barroso <span>Oncologista Clínico<br> CRM 25325/DF</span></h5>
          </div>
        </div>


        <!-- DUPLO -->
        <div class="palestrantes-conteudo-duplo">
          <p class="palestrantes-area">Pulmão</p>
          <div class="palestrantes-conteudo-lista-item" title="Dra. Aknar Calabrich">
            <img src="assets/img/personas/dra-aknar-calabrich.webp" alt="Dra. Aknar Calabrich">
            <h5>Dra. Aknar Calabrich <span>Oncologista Clínica<br> CRM 21855/BA</span></h5>
          </div>
          <div class="palestrantes-conteudo-lista-item" title="Dra. Carolina Kawamura">
            <img src="assets/img/personas/dra-carolina-kawamura.webp" alt="Dra. Carolina Kawamura">
            <h5>Dra. Carolina Kawamura <span>Oncologista Clínico <br>CRM 119713/SP</span></h5>
          </div>
        </div>


        <!-- TRIPLO -->
        <div class="palestrantes-conteudo-triplo">
          <p class="palestrantes-area">Geniturinário</p>
          <div class="palestrantes-conteudo-lista-item" title="Dr. Augusto Mota">
            <img src="assets/img/personas/dr-augusto-mota.webp" alt="Dr. Augusto Mota">
            <h5>Dr. Augusto Mota <span>Oncologista Clínico<br> CRM 14397 /BA</span></h5>
          </div>
          <div class="palestrantes-conteudo-lista-item" title="Dr. Carlos Dzik">
            <img src="assets/img/personas/dr-carlos-dzik.webp" alt="Dr. Carlos Dzik">
            <h5>Dr. Carlos Dzik <span>Oncologista Clínico<br> CRM 63238/SP</span></h5>
          </div>
          <div class="palestrantes-conteudo-lista-item" title="Dr. Fernando Vidigal">
            <img src="assets/img/personas/dr-fernando-vidigal.webp" alt="Dr. Fernando Vidigal">
            <h5>Dr. Fernando Vidigal <span>Oncologista Clínico<br> CRM 22020/DF</span></h5>
          </div>
        </div>



        <!-- SINGLE -->
        <div class="palestrantes-conteudo-single">
          <p class="palestrantes-area">Gastrointestinal</p>
          <div class="palestrantes-conteudo-lista-item" title="Dra. Anelisa Coutinho">
            <img src="assets/img/personas/dra-anelisa-coutinho.webp" alt="Dra. Anelisa Coutinho">
            <h5>Dra. Anelisa Coutinho <span>Oncologista Clínica<br> CRM 11452/BA</span></h5>
          </div>
        </div>


        <!-- SINGLE -->
        <div class="palestrantes-conteudo-single">
          <p class="palestrantes-area">Tumores do sistema nervoso central</p>
          <div class="palestrantes-conteudo-lista-item" title="Dra. Caroline Chaul">
            <img src="assets/img/personas/dra-caroline-chaul.webp" alt="Dra. Caroline Chaul">
            <h5>Dra. Caroline Chaul <span>Oncologista Clínica<br> CRM 131520/SP</span></h5>
          </div>
        </div>


        <!-- SINGLE -->
        <div class="palestrantes-conteudo-single">
          <p class="palestrantes-area">Oncoginecologia</p>
          <div class="palestrantes-conteudo-lista-item" title="Dra. Mariana Scaranti">
            <img src="assets/img/personas/dra-mariana-scaranti.webp" alt="Dra. Mariana Scaranti">
            <h5>Dra. Mariana Scaranti <span>Oncologista Clínica<br> CRM 144409/SP</span></h5>
          </div>
        </div>


        <!-- SINGLE -->
        <div class="palestrantes-conteudo-single">
          <p class="palestrantes-area">Saúde da mulher  em oncologia</p>
          <div class="palestrantes-conteudo-lista-item" title="Dr. Marcelo Simonsen">
            <img src="assets/img/personas/dr-marcelo-simonsen.webp" alt="Dr. Marcelo Simonsen">
            <h5>Dr. Marcelo Simonsen <span>Ginecologista Especialista em Oncologia Ginecológica - CRM 131387/SP</span></h5>
          </div>
        </div>


        <!-- DUPLO -->
        <div class="palestrantes-conteudo-duplo">
          <p class="palestrantes-area">Hematologia</p>
          <div class="palestrantes-conteudo-lista-item" title="Dr. Celso Arrais">
            <img src="assets/img/personas/dr-celso-arrais.webp" alt="Dr. Celso Arrais">
            <h5>Dr. Celso Arrais <span>Onco-hematologia<br> CRM 98682/SP</span></h5>
          </div>
          <div class="palestrantes-conteudo-lista-item" title="Dr. Daniel Tabak">
            <img src="assets/img/personas/dr-daniel-tabak.webp" alt="Dr. Daniel Tabak">
            <h5>Dr. Daniel Tabak <span>Onco-hematologia<br> CRM 335773/RJ</span></h5>
          </div>
        </div>


        <!-- DUPLO -->
        <div class="palestrantes-conteudo-duplo">
          <p class="palestrantes-area">Melanoma e Sarcoma</p>
          <div class="palestrantes-conteudo-lista-item" title="Dr. Iuri Melo">
            <img src="assets/img/personas/dr-iuri-santana.webp" alt="Dr. Iuri Melo">
            <h5>Dr. Iuri Melo <span>Oncologista Clínico<br> CRM 26191/BA</span></h5>
          </div>
          <div class="palestrantes-conteudo-lista-item" title="Dr. Rafael Schmerling">
            <img src="assets/img/personas/dr-rafael-schmerling.webp" alt="Dr. Rafael Schmerling">
            <h5>Dr. Rafael Schmerling <span>Oncologista Clínico<br> CRM 97291/SP</span></h5>
          </div>
        </div>


        <!-- SINGLE -->
        <div class="palestrantes-conteudo-single">
          <p class="palestrantes-area">Cabeça e Pescoço</p>
          <div class="palestrantes-conteudo-lista-item" title="Dr. Tiago Kenji">
            <img src="assets/img/personas/dr-tiago-kenji.webp" alt="Dr. Tiago Kenji">
            <h5>Dr. Tiago Kenji <span>Oncologista Clínico<br> CRM 125042/SP</span></h5>
          </div>
        </div>


        <!-- SINGLE -->
        <div class="palestrantes-conteudo-single">
          <p class="palestrantes-area">Medicina Intensiva e Cardio-oncologia</p>
          <div class="palestrantes-conteudo-lista-item" title="Marcos Tavares">
            <img src="assets/img/personas/dr-marcos-tavares.webp" alt="Marcos Tavares">
            <h5>Marcos Tavares <span>Pneumologista <br>CRM 121046/SP</span></h5>
          </div>
        </div>


        <!-- SINGLE -->
        <div class="palestrantes-conteudo-single">
          <p class="palestrantes-area">Experiência do paciente</p>
          <div class="palestrantes-conteudo-lista-item" title="Adriana Alves">
            <img src="assets/img/personas/dra-adriana-alves.webp" alt="Adriana Alves">
            <h5>Adriana Alves <span>Diretoria Assistencial <br>de Oncologia Dasa</span></h5>
          </div>
        </div>
        
      </div>

    </div>

  </content>
    <?php include 'inc/footer.php' ?>
  <script src="assets/js/jquery.min.js"></script>
  <script src="assets/js/scroll-out.js"></script>
  <script src="assets/js/scripts.js"></script>
  <script src="assets/js/flickity-docs.min.js"></script>
</body>
</html>